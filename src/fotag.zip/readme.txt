Platform: Mac
Version of Java: 8.1

"make run" to run the program; main function is in Main.java;
Model: Fotag.java, imageModel.java
View: Toolbar.java, MainWindow.java, ImageView.java

Use the load icon to load image on screen.
Use the first and second icon to switch between grid layout and list layout.
Press the stars to rate images; Press the stars on toobar to filter images by rating.
Click image to enlarge image in a seperate window.